<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class tbl_rperfiles extends Model
{
    //
}
