<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateTblRusuariosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_rusuarios', function (Blueprint $table) {
            $table->bigIncrements('usu_nid');
            $table->string('usu_semail',100);
            $table->string('usu_sclave',100);
            $table->boolean('usu_bestado');
            $table->datetime('usu_dregistro');

            $table->unsignedbiginteger('per_nid');
            $table->foreign('per_nid')->references('per_nid')->on('tbl_rperfiles');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_rusuarios');
    }
}
