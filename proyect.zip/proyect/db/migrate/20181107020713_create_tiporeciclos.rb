class CreateTiporeciclos < ActiveRecord::Migration[5.1]
  def change
    create_table :tiporeciclos do |t|
      t.string :description
      t.integer :id_imagen
      t.boolen :status

      t.timestamps
    end
  end
end
