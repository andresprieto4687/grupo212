require 'test_helper'

class TiporecicloTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
