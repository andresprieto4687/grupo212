require 'test_helper'

class TiporeciclosControllerTest < ActionDispatch::IntegrationTest
  setup do
    @tiporeciclo = tiporeciclos(:one)
  end

  test "should get index" do
    get tiporeciclos_url, as: :json
    assert_response :success
  end

  test "should create tiporeciclo" do
    assert_difference('Tiporeciclo.count') do
      post tiporeciclos_url, params: { tiporeciclo: { description: @tiporeciclo.description, id_imagen: @tiporeciclo.id_imagen, status: @tiporeciclo.status } }, as: :json
    end

    assert_response 201
  end

  test "should show tiporeciclo" do
    get tiporeciclo_url(@tiporeciclo), as: :json
    assert_response :success
  end

  test "should update tiporeciclo" do
    patch tiporeciclo_url(@tiporeciclo), params: { tiporeciclo: { description: @tiporeciclo.description, id_imagen: @tiporeciclo.id_imagen, status: @tiporeciclo.status } }, as: :json
    assert_response 200
  end

  test "should destroy tiporeciclo" do
    assert_difference('Tiporeciclo.count', -1) do
      delete tiporeciclo_url(@tiporeciclo), as: :json
    end

    assert_response 204
  end
end
