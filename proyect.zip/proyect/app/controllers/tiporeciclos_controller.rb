class TiporeciclosController < ApplicationController
  before_action :set_tiporeciclo, only: [:show, :update, :destroy]

  # GET /tiporeciclos
  def index
    @tiporeciclos = Tiporeciclo.all

    render json: @tiporeciclos
  end

  # GET /tiporeciclos/1
  def show
    render json: @tiporeciclo
  end

  # POST /tiporeciclos
  def create
    @tiporeciclo = Tiporeciclo.new(tiporeciclo_params)

    if @tiporeciclo.save
      render json: @tiporeciclo, status: :created, location: @tiporeciclo
    else
      render json: @tiporeciclo.errors, status: :unprocessable_entity
    end
  end

  # PATCH/PUT /tiporeciclos/1
  def update
    if @tiporeciclo.update(tiporeciclo_params)
      render json: @tiporeciclo
    else
      render json: @tiporeciclo.errors, status: :unprocessable_entity
    end
  end

  # DELETE /tiporeciclos/1
  def destroy
    @tiporeciclo.destroy
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_tiporeciclo
      @tiporeciclo = Tiporeciclo.find(params[:id])
    end

    # Only allow a trusted parameter "white list" through.
    def tiporeciclo_params
      params.require(:tiporeciclo).permit(:description, :id_imagen, :status)
    end
end
