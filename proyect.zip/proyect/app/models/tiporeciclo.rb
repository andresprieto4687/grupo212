class Tiporeciclo < ApplicationRecord
end
