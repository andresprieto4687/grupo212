<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\reciclausers;
use App\User;
use App\Http\Resources\resiclausers;
use App\fedesoft\Procedures;


class usuarioController extends Controller
{

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
  //Lo almacenaré en una propiedad  heredable.
 

       //Con cualquier metodo que tu crees solo tendrias que llamarlo de la siguiente manerá


       /*public function GetUsuario()
       {
           return \DB::select('CALL SPR_GET_PERFIL');
       }*/
    

 

  


    public function index()
    {
        //return $this->GetUsuario();

          return User::all();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //Es para el formulario en el cual se ingresan los datos y crear el usuario
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
        //$Rules=['name'=>'required'];

        //$this->validate($request, $Rules);

        //$this->validate($request,['name' => 'required']);  

        //Crea un usuario
        $reciclausers = new User;
        $reciclausers -> email = $request -> email;
        $reciclausers -> password = bcrypt($request -> password);
        //$reciclausers -> status = $request -> status;
        $reciclausers -> name = $request -> name;
       // $reciclausers -> perfilId = $request -> perfilId;



        $reciclausers -> save();
        return "Registro creado exitosamente";
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        // Muestra solo un usuario
        //return $id;
        $data = User::find($id);
       // return $data;
       return $data;
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //Vista del formulario para actualizar un usuario
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //Actualizar un usuario
        $reciclausers = reciclausers::find($id);
        $reciclausers -> fill($request->all());
        $reciclausers -> save();
        return $reciclausers;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //Eliminar un usuario
        $reciclausers = reciclausers::find($id);
        $reciclausers -> delete();
        return "OK eliminado";
    }
}
