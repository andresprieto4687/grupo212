<?php

namespace App\Http\Controllers;

use App\reciclaresiduo;
use Illuminate\Http\Request;

class reciclaresiduoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\reciclaresiduo  $reciclaresiduo
     * @return \Illuminate\Http\Response
     */
    public function show(reciclaresiduo $reciclaresiduo)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\reciclaresiduo  $reciclaresiduo
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, reciclaresiduo $reciclaresiduo)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\reciclaresiduo  $reciclaresiduo
     * @return \Illuminate\Http\Response
     */
    public function destroy(reciclaresiduo $reciclaresiduo)
    {
        //
    }
}
