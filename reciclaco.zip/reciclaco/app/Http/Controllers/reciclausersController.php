<?php

namespace App\Http\Controllers;

use App\reciclausers;
use Illuminate\Http\Request;

class reciclausersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\reciclausers  $reciclausers
     * @return \Illuminate\Http\Response
     */
    public function show(reciclausers $reciclausers)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\reciclausers  $reciclausers
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, reciclausers $reciclausers)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\reciclausers  $reciclausers
     * @return \Illuminate\Http\Response
     */
    public function destroy(reciclausers $reciclausers)
    {
        //
    }
}
