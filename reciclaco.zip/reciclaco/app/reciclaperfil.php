<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class reciclaperfil extends Model
{
    //

    public function usuarios()
    {
     return $this->hasMany(reciclausers::class,'perfilid','id');
     //llave del modelo con el que se relaciona  llave forane llave  tabla
    }

}
