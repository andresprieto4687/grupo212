<?php

namespace App\Traits;

trait Inicio {
    //Metodo que llamará a mi procedimiento
        protected function GetUsuario()
        {
            return \DB::select('CALL SPR_GET_PERFIL');
        }
    }
