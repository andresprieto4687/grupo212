<?php
//Especifico la ruta donde se encuentra este archivo
namespace App\fedesoft\Procedures;
//Nombre de la clase
class UsuarioProcedure {
//Metodo que llamará a mi procedimiento
    public function GetUsuario()
    {
        return \DB::select('CALL SPR_GET_PERFIL');
    }
}