<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
	return $request->user();
});

//Route::get('usuarios', 'usuarioController@index');
//palabra de la url, nombre del controlador 

Route::resource('usuarios', 'usuarioController')->middleware('client');
Route::resource('perfiles', 'reciclaperfilController');
Route::resource('estados', 'reciclarstatusController');
Route::resource('tiposmenu', 'tipomenuController');
Route::resource('comentarios', 'reciclacomentarioController');
//Route::resource('tiposresiduos', 'tiporesiduoController');
Route::get('login',function(){
	return ['error'=>'usuario debe autenticarse'];
})->name('login');

Route::post('oauth/token', '\Laravel\Passport\Http\Controllers\AccessTokenController@issueToken');