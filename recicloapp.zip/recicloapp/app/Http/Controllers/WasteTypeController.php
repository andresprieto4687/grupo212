<?php

namespace App\Http\Controllers;

use App\WasteType;
use Illuminate\Http\Request;

class WasteTypeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\WasteType  $wasteType
     * @return \Illuminate\Http\Response
     */
    public function show(WasteType $wasteType)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\WasteType  $wasteType
     * @return \Illuminate\Http\Response
     */
    public function edit(WasteType $wasteType)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\WasteType  $wasteType
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, WasteType $wasteType)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\WasteType  $wasteType
     * @return \Illuminate\Http\Response
     */
    public function destroy(WasteType $wasteType)
    {
        //
    }
}
