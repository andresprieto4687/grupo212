<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WasteType extends Model
{
    //
}
