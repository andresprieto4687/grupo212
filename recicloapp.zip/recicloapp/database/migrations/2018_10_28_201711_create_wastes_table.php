<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateWastesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_rwaste', function (Blueprint $table) {
            $table->increments('id');
            $table->string('description', 100);
            $table->boolean('status', 1)->default(true);
            $table->integer('imageId')->unsigned();
            $table->foreign('imageId')->references('id')->on('tbl_rimage');
            $table->integer('wastetypeId')->unsigned();
            $table->foreign('wastetypeId')->references('id')->on('tbl_rwaste_type');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('tbl_rwaste');
    }
}

