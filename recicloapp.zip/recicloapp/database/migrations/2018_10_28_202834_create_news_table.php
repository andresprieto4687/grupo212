<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateNewsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('tbl_tnews', function (Blueprint $table) {
            $table->increments('id');
            $table->string('description', 500);
            $table->string('detail', 500);
            $table->boolean('status', 1)->default(true);
            $table->integer('commentaryId')->unsigned();
            $table->foreign('commentaryId')->references('id')->on('tbl_tcommentary');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {

        Schema::dropIfExists('tbl_tnews');
    }
}
