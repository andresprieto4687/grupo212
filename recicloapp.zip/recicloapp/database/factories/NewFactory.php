<?php

use Faker\Generator as Faker;

$factory->define(App\new::class, function (Faker $faker) {
    return [
        //
    ];
});
