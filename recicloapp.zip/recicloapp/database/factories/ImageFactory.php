<?php

use Faker\Generator as Faker;

$factory->define(App\image::class, function (Faker $faker) {
    return [
        //
    ];
});
