<?php

use Faker\Generator as Faker;

$factory->define(App\tip::class, function (Faker $faker) {
    return [
        //
    ];
});
