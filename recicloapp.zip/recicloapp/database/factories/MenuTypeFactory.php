<?php

use Faker\Generator as Faker;

$factory->define(App\MenuType::class, function (Faker $faker) {
    return [
        //
    ];
});
