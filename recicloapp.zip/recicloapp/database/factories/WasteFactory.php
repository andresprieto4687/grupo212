<?php

use Faker\Generator as Faker;

$factory->define(App\Waste::class, function (Faker $faker) {
    return [
        //
    ];
});
