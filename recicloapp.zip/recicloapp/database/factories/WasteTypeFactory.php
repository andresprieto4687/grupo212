<?php

use Faker\Generator as Faker;

$factory->define(App\WasteType::class, function (Faker $faker) {
    return [
        //
    ];
});
