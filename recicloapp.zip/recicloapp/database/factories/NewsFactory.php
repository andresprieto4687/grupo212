<?php

use Faker\Generator as Faker;

$factory->define(App\news::class, function (Faker $faker) {
    return [
        //
    ];
});
