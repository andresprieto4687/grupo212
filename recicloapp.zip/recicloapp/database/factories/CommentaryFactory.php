<?php

use Faker\Generator as Faker;

$factory->define(App\commentary::class, function (Faker $faker) {
    return [
        //
    ];
});
